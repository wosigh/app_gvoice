function ExpiredAssistant() {
		
}

ExpiredAssistant.prototype.setup = function() {	

}